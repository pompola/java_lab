package com.example.app.controller;

import com.example.app.entity.Oborudovanie;
import com.example.app.service.OborudovanieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/oborudovanie")
public class OborudovanieController {

    private final OborudovanieService oborudovanieService;

    @Autowired
    public OborudovanieController(OborudovanieService oborudovanieService) {
        this.oborudovanieService = oborudovanieService;
    }

    @GetMapping("/list")
    public String listOborudovanies(Model model) {
        model.addAttribute("oborudovanies", oborudovanieService.getAllOborudovanies());
        return "oborudovanie/oborudovanie-list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("oborudovanie", new Oborudovanie());
        return "oborudovanie/oborudovanie-form";
    }

    @PostMapping("/add")
    public String addOborudovanie(@ModelAttribute Oborudovanie oborudovanie) {
        oborudovanieService.save(oborudovanie);
        return "redirect:/oborudovanie/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        Oborudovanie oborudovanie = oborudovanieService.getOborudovanieById(id);
        if (oborudovanie == null) {
            return "redirect:/oborudovanie/list";
        }
        model.addAttribute("oborudovanie", oborudovanie);
        return "oborudovanie/oborudovanie-form";
    }

    @PostMapping("/edit/{id}")
    public String editOborudovanie(@PathVariable Integer id, @ModelAttribute Oborudovanie oborudovanie) {
        oborudovanie.setId(id);
        oborudovanieService.save(oborudovanie);
        return "redirect:/oborudovanie/list";
    }

    @GetMapping("/delete/{id}")
    public String deleteOborudovanie(@PathVariable Integer id) {
        oborudovanieService.deleteOborudovanie(id);
        return "redirect:/oborudovanie/list";
    }

    @GetMapping("/view/{id}")
    public String viewOborudovanie(@PathVariable Integer id, Model model) {
        Oborudovanie oborudovanie = oborudovanieService.getOborudovanieById(id);
        if (oborudovanie == null) {
            return "redirect:/oborudovanie/list";
        }
        model.addAttribute("oborudovanie", oborudovanie);
        return "oborudovanie/oborudovanie-view";
    }
}

