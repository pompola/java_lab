package com.example.app.repository;

import com.example.app.entity.Oborudovanie;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OborudovanieRepository extends JpaRepository<Oborudovanie, Integer> {
}
