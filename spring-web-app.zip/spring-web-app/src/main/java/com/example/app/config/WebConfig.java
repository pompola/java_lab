package com.example.app.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("index");
        registry.addViewController("/client").setViewName("client/client-list");
        registry.addViewController("/cotrudnik").setViewName("cotrudnik/cotrudnik-list");
        registry.addViewController("/kvitok").setViewName("kvitok/kvitok-list");
        registry.addViewController("/oborudovanie").setViewName("oborudovanie/oborudovanie-list");
    }
}
