package com.example.app.repository;

import com.example.app.entity.Kvitok;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface KvitokRepository extends JpaRepository<Kvitok, Integer> {
    boolean existsByClient_Id(Integer clientId);
    List<Kvitok> findByDate1Between(LocalDate startDate, LocalDate endDate);
    boolean existsByCotrudnik_Id(Integer cotrudnikId);

}
