package com.example.app.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "client")
@Data
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_client")
    private Integer id;

    @Column(name = "number", unique = true, nullable = false)
    private Long number;

    @Column(name = "familia", nullable = false)
    private String familia;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "otchestvo")
    private String otchestvo;
}
