package com.example.app.controller;

import com.example.app.entity.Cotrudnik;
import com.example.app.service.CotrudnikService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Comparator;
import java.util.List;

@Controller
@RequestMapping("/cotrudnik")
public class CotrudnikController {

    private final CotrudnikService cotrudnikService;

    @Autowired
    public CotrudnikController(CotrudnikService cotrudnikService) {
        this.cotrudnikService = cotrudnikService;
    }

    @GetMapping("/list")
    public String listCotrudniks(Model model) {
        List<Cotrudnik> cotrudniks = cotrudnikService.getAllCotrudniks();

        cotrudniks.sort(Comparator.comparing(Cotrudnik::getId));

        model.addAttribute("cotrudniks", cotrudniks);
        return "cotrudnik/cotrudnik-list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("cotrudnik", new Cotrudnik());
        return "cotrudnik/cotrudnik-form";
    }

    @PostMapping("/add")
    public String addCotrudnik(@ModelAttribute Cotrudnik cotrudnik) {
        cotrudnikService.saveCotrudnik(cotrudnik);
        return "redirect:/cotrudnik/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        Cotrudnik cotrudnik = cotrudnikService.getCotrudnikById(id);
        if (cotrudnik == null) {
            return "redirect:/cotrudnik/list";
        }
        model.addAttribute("cotrudnik", cotrudnik);
        return "cotrudnik/cotrudnik-form";
    }

    @PostMapping("/edit/{id}")
    public String editCotrudnik(@PathVariable Integer id, @ModelAttribute Cotrudnik cotrudnik) {
        cotrudnik.setId(id);
        cotrudnikService.saveCotrudnik(cotrudnik);
        return "redirect:/cotrudnik/list";
    }

    @GetMapping("/delete/{id}")
    public String deleteCotrudnik(@PathVariable Integer id, RedirectAttributes redirectAttributes) {
        if (cotrudnikService.hasAssociatedKvitoks(id)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Нельзя удалить сотрудника. Удалите квиток.");
            return "redirect:/cotrudnik/list";
        }

        cotrudnikService.deleteCotrudnik(id);
        return "redirect:/cotrudnik/list";
    }
    @GetMapping("/view/{id}")
    public String viewCotrudnik(@PathVariable Integer id, Model model) {
        Cotrudnik cotrudnik = cotrudnikService.getCotrudnikById(id);
        if(cotrudnik == null)
            return "redirect:/cotrudnik/list";

        model.addAttribute("cotrudnik", cotrudnik);
        return "cotrudnik/cotrudnik-view";
    }
}
