package com.example.app.service;

import com.example.app.entity.Client;
import com.example.app.repository.ClientRepository;
import com.example.app.repository.KvitokRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClientService {

    private final ClientRepository clientRepository;
    private final KvitokRepository kvitokRepository;

    @Autowired
    public ClientService(ClientRepository clientRepository, KvitokRepository kvitokRepository) {
        this.clientRepository = clientRepository;
        this.kvitokRepository = kvitokRepository;
    }

    public List<Client> getAllClients() {
        return clientRepository.findAll();
    }

    public Client getClientById(Integer id) {
        return clientRepository.findById(id).orElse(null);
    }

    public void save(Client client) {
        if (!clientRepository.existsById(client.getId())) {
            clientRepository.save(client);
        } else {
            throw new IllegalArgumentException("Client with ID " + client.getId() + " already exists");
        }
    }

    public void deleteClient(Integer id) {
        if (!hasAssociatedKvitoks(id)) {
            clientRepository.deleteById(id);
        } else {
            throw new IllegalStateException("Cannot delete client with associated kvitoks");
        }
    }

    public boolean hasAssociatedKvitoks(Integer clientId) {
        return kvitokRepository.existsByClient_Id(clientId);
    }
}
