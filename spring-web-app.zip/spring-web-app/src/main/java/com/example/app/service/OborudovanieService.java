package com.example.app.service;

import com.example.app.entity.Oborudovanie;
import com.example.app.repository.OborudovanieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OborudovanieService {

    private final OborudovanieRepository oborudovanieRepository;

    @Autowired
    public OborudovanieService(OborudovanieRepository oborudovanieRepository) {
        this.oborudovanieRepository = oborudovanieRepository;
    }

    public List<Oborudovanie> getAllOborudovanies() {
        return oborudovanieRepository.findAll();
    }

    public Oborudovanie getOborudovanieById(Integer id) {
        return oborudovanieRepository.findById(id).orElse(null);
    }

    // Метод для сохранения оборудования
    public void save(Oborudovanie oborudovanie) {
        oborudovanieRepository.save(oborudovanie);
    }

    // Метод для удаления оборудования
    public void deleteOborudovanie(Integer id){
        oborudovanieRepository.deleteById(id);
    }
}
