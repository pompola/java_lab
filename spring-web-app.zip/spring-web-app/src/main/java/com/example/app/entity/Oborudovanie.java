package com.example.app.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "oborudovanie")
@Data
public class Oborudovanie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_oborud")
    private Integer id;

    @Column(name = "oborud_name", unique = true, nullable = false)
    private String name;

    @Column(name = "location")
    private String location;

    @Column(name = "condition")
    private String condition;

    @Column(name = "price_day")
    public Integer cost;
}
