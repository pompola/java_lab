package com.example.app.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "cotrudnik")
@Data
public class Cotrudnik {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cotrudnik")
    private Integer id;

    @Column(name = "familia", nullable = false)
    private String familia;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "otchestvo")
    private String otchestvo;

}
