package com.example.app.controller;

import com.example.app.entity.Kvitok;
import com.example.app.entity.Oborudovanie;
import com.example.app.service.KvitokService;
import com.example.app.service.OborudovanieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/report")
public class ReportController {

    private final OborudovanieService oborudovanieService;
    private final KvitokService kvitokService;

    @Autowired
    public ReportController(OborudovanieService oborudovanieService, KvitokService kvitokService) {
        this.oborudovanieService = oborudovanieService;
        this.kvitokService = kvitokService;
    }

    @GetMapping("/oborudovanie_nalichie")
    public String oborudovanieNalichie(Model model) {
        List<Oborudovanie> oborudovanies = oborudovanieService.getAllOborudovanies().stream()
                .filter(oborudovanie -> "склад".equalsIgnoreCase(oborudovanie.getLocation()))
                .collect(Collectors.toList());
        model.addAttribute("oborudovanies", oborudovanies);
        return "report/oborudovanie-nalichie";
    }

    @GetMapping("/arenda_oborudovanie")
    public String arendaOborudovanie(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            Model model) {

        List<Kvitok> kvitoks;
        if (startDate != null && endDate != null) {
            kvitoks = kvitokService.getKvitoksByDateRange(startDate, endDate);
        } else {
            kvitoks = kvitokService.getAllKvitoks();
        }

        double totalCost = kvitoks.stream()
                .mapToDouble(kvitok -> kvitok.getCost() == null ? 0 : kvitok.getCost())
                .sum();

        model.addAttribute("kvitoks", kvitoks);
        model.addAttribute("totalCost", totalCost);
        model.addAttribute("startDate", startDate);
        model.addAttribute("endDate", endDate);
        return "report/arenda-oborudovanie";
    }
}
