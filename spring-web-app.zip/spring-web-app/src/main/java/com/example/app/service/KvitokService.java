package com.example.app.service;

import com.example.app.entity.Kvitok;
import com.example.app.repository.KvitokRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class KvitokService {

    private final KvitokRepository kvitokRepository;

    @Autowired
    public KvitokService(KvitokRepository kvitokRepository) {
        this.kvitokRepository = kvitokRepository;
    }

    public List<Kvitok> getAllKvitoks() {
        return kvitokRepository.findAll();
    }

    public Kvitok getKvitokById(Integer id) {
        return kvitokRepository.findById(id).orElse(null);
    }

    public void saveKvitok(Kvitok kvitok) {
        kvitokRepository.save(kvitok);
    }

    public void deleteKvitok(Integer id) {
        kvitokRepository.deleteById(id);
    }

    public List<Kvitok> getKvitoksByDateRange(LocalDate startDate, LocalDate endDate) {
        return kvitokRepository.findByDate1Between(startDate, endDate);
    }
}
