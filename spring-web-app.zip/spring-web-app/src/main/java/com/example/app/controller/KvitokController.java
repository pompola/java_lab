package com.example.app.controller;

import com.example.app.entity.Client;
import com.example.app.entity.Cotrudnik;
import com.example.app.entity.Kvitok;
import com.example.app.entity.Oborudovanie;
import com.example.app.service.ClientService;
import com.example.app.service.CotrudnikService;
import com.example.app.service.KvitokService;
import com.example.app.service.OborudovanieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

@Controller
@RequestMapping("/kvitok")
public class KvitokController {

    private final KvitokService kvitokService;
    private final ClientService clientService;
    private final CotrudnikService cotrudnikService;
    private final OborudovanieService oborudovanieService;

    @Autowired
    public KvitokController(KvitokService kvitokService, ClientService clientService, CotrudnikService cotrudnikService, OborudovanieService oborudovanieService) {
        this.kvitokService = kvitokService;
        this.clientService = clientService;
        this.cotrudnikService = cotrudnikService;
        this.oborudovanieService = oborudovanieService;
    }

    @GetMapping("/list")
    public String listKvitoks(Model model) {
        model.addAttribute("kvitoks", kvitokService.getAllKvitoks());
        return "kvitok/kvitok-list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("kvitok", new Kvitok());
        model.addAttribute("clients", clientService.getAllClients());
        model.addAttribute("cotrudniks", cotrudnikService.getAllCotrudniks());
        model.addAttribute("oborudovanies", oborudovanieService.getAllOborudovanies());
        return "kvitok/kvitok-form";
    }


    @PostMapping("/add")
    public String addKvitok(
            @ModelAttribute Kvitok kvitok,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date1,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date2
    ) {
        Client client = clientService.getClientById(kvitok.getClient().getId());
        Cotrudnik cotrudnik = cotrudnikService.getCotrudnikById(kvitok.getCotrudnik().getId());
        Oborudovanie oborudovanie = oborudovanieService.getOborudovanieById(kvitok.getOborudovanie().getId());

        kvitok.setClient(client);
        kvitok.setCotrudnik(cotrudnik);
        kvitok.setOborudovanie(oborudovanie);
        kvitok.setDate1(date1);
        kvitok.setDate2(date2);


        kvitokService.saveKvitok(kvitok);
        return "redirect:/kvitok/list";
    }


    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        Kvitok kvitok = kvitokService.getKvitokById(id);
        if (kvitok == null) {
            return "redirect:/kvitok/list";
        }
        model.addAttribute("kvitok", kvitok);
        model.addAttribute("clients", clientService.getAllClients());
        model.addAttribute("cotrudniks", cotrudnikService.getAllCotrudniks());
        model.addAttribute("oborudovanies", oborudovanieService.getAllOborudovanies());
        return "kvitok/kvitok-form";
    }

    @PostMapping("/edit/{id}")
    public String editKvitok(
            @PathVariable Integer id,
            @ModelAttribute Kvitok kvitok,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date1,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date2
    ) {

        Client client = clientService.getClientById(kvitok.getClient().getId());
        Cotrudnik cotrudnik = cotrudnikService.getCotrudnikById(kvitok.getCotrudnik().getId());
        Oborudovanie oborudovanie = oborudovanieService.getOborudovanieById(kvitok.getOborudovanie().getId());

        kvitok.setClient(client);
        kvitok.setCotrudnik(cotrudnik);
        kvitok.setOborudovanie(oborudovanie);
        kvitok.setDate1(date1);
        kvitok.setDate2(date2);

        kvitok.setId(id);
        kvitokService.saveKvitok(kvitok);
        return "redirect:/kvitok/list";
    }

    @GetMapping("/delete/{id}")
    public String deleteKvitok(@PathVariable Integer id) {
        kvitokService.deleteKvitok(id);
        return "redirect:/kvitok/list";
    }
    @GetMapping("/calculateCost")
    @ResponseBody
    public String calculateCost(
            @RequestParam Integer oborudovanieId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date1,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date2)
    {
        Oborudovanie oborudovanie = oborudovanieService.getOborudovanieById(oborudovanieId);
        long days = ChronoUnit.DAYS.between(date1, date2) + 1;
        Integer cost = (int) (oborudovanie.getCost() * days);
        return String.valueOf(cost);
    }
}
