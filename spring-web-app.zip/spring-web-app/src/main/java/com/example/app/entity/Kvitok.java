package com.example.app.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;


@Entity
@Table(name = "kvitok")
@Data
public class Kvitok {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "kvitok_number")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "cotrudnik", referencedColumnName = "id_cotrudnik")
    private Cotrudnik cotrudnik;

    @Column(name = "date_1", nullable = false)
    private LocalDate date1;

    @Column(name = "date_2", nullable = false)
    private LocalDate date2;

    @ManyToOne
    @JoinColumn(name = "client", referencedColumnName = "id_client")
    private Client client;

    @ManyToOne
    @JoinColumn(name = "oborudovanie", referencedColumnName = "id_oborud")
    private Oborudovanie oborudovanie;

    @Column(name = "cost")
    private Integer cost;
}
