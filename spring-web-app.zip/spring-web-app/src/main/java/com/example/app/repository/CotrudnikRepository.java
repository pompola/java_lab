package com.example.app.repository;

import com.example.app.entity.Cotrudnik;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CotrudnikRepository extends JpaRepository<Cotrudnik, Integer> {
}
