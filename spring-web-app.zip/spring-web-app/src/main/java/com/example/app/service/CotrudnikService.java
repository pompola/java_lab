package com.example.app.service;

import com.example.app.entity.Cotrudnik;
import com.example.app.repository.CotrudnikRepository;
import com.example.app.repository.KvitokRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CotrudnikService {

    private final CotrudnikRepository cotrudnikRepository;
    private final KvitokRepository kvitokRepository;

    @Autowired
    public CotrudnikService(CotrudnikRepository cotrudnikRepository, KvitokRepository kvitokRepository) {
        this.cotrudnikRepository = cotrudnikRepository;
        this.kvitokRepository = kvitokRepository;
    }

    public List<Cotrudnik> getAllCotrudniks() {
        return cotrudnikRepository.findAll();
    }

    public Cotrudnik getCotrudnikById(Integer id) {
        return cotrudnikRepository.findById(id).orElse(null);
    }

    public void saveCotrudnik(Cotrudnik cotrudnik) {
        cotrudnikRepository.save(cotrudnik);
    }

    public void deleteCotrudnik(Integer id) {
        cotrudnikRepository.deleteById(id);
    }
    public boolean hasAssociatedKvitoks(Integer cotrudnikId) {
        return kvitokRepository.existsByCotrudnik_Id(cotrudnikId);
    }
}
