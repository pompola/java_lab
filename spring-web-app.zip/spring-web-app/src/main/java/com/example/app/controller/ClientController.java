package com.example.app.controller;

import com.example.app.entity.Client;
import com.example.app.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.List;
import java.util.Comparator;

@Controller
@RequestMapping("/client")
public class ClientController {

    private final ClientService clientService;

    @Autowired
    public ClientController(ClientService clientService) {
        this.clientService = clientService;
    }

    @GetMapping("/list")
    public String listClients(Model model) {
        List<Client> clients = clientService.getAllClients();

        clients.sort(Comparator.comparing(Client::getId));

        model.addAttribute("clients", clients);
        return "client/client-list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("client", new Client());
        return "client/client-form";
    }

    @PostMapping("/add")
    public String addClient(@ModelAttribute Client client) {
        clientService.save(client);
        return "redirect:/client/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        Client client = clientService.getClientById(id);
        if (client == null)
            return "redirect:/client/list";
        model.addAttribute("client", client);
        return "client/client-form";
    }
    @PostMapping("/edit/{id}")
    public String editClient(@PathVariable Integer id, @ModelAttribute Client client) {
        client.setId(id);
        clientService.save(client);
        return "redirect:/client/list";
    }

    @GetMapping("/delete/{id}")
    public String deleteClient(@PathVariable Integer id, RedirectAttributes redirectAttributes){
        if (clientService.hasAssociatedKvitoks(id)) {
            redirectAttributes.addFlashAttribute("errorMessage", "Нельзя удалить клиента. Удалите квиток.");
            return "redirect:/client/list";
        }

        clientService.deleteClient(id);
        return "redirect:/client/list";
    }
    @GetMapping("/view/{id}")
    public String viewClient(@PathVariable Integer id, Model model) {
        Client client = clientService.getClientById(id);
        if (client == null)
            return "redirect:/client/list";
        model.addAttribute("client", client);
        return "client/client-view";
    }
}
